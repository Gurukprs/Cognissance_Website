import React from "react";

const Hackathon = () => {
  return (
    <div style={{ padding: "2rem" }}>
      <h1>Hackathon Registration Page</h1>
      <p>This is a placeholder for the registration form for Hackathon.</p>
    </div>
  );
};

export default Hackathon;
