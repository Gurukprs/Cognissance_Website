import React from "react";

const ArtAndCraftExhibition = () => {
  return (
    <div style={{ padding: "2rem" }}>
      <h1>ArtAndCraftExhibition Registration Page</h1>
      <p>This is a placeholder for the registration form for ArtAndCraftExhibition.</p>
    </div>
  );
};

export default ArtAndCraftExhibition;
