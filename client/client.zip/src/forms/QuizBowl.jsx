import React from "react";

const QuizBowl = () => {
  return (
    <div style={{ padding: "2rem" }}>
      <h1>QuizBowl Registration Page</h1>
      <p>This is a placeholder for the registration form for QuizBowl.</p>
    </div>
  );
};

export default QuizBowl;
