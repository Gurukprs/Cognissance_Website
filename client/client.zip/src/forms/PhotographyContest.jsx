import React from "react";

const PhotographyContest = () => {
  return (
    <div style={{ padding: "2rem" }}>
      <h1>PhotographyContest Registration Page</h1>
      <p>This is a placeholder for the registration form for PhotographyContest.</p>
    </div>
  );
};

export default PhotographyContest;
