import React from "react";

const PublicSpeaking = () => {
  return (
    <div style={{ padding: "2rem" }}>
      <h1>PublicSpeaking Registration Page</h1>
      <p>This is a placeholder for the registration form for PublicSpeaking.</p>
    </div>
  );
};

export default PublicSpeaking;
