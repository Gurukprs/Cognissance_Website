import React from "react";

const DebuggingChallenge = () => {
  return (
    <div style={{ padding: "2rem" }}>
      <h1>DebuggingChallenge Registration Page</h1>
      <p>This is a placeholder for the registration form for DebuggingChallenge.</p>
    </div>
  );
};

export default DebuggingChallenge;
