import React from "react";

const MachineLearningChallenge = () => {
  return (
    <div style={{ padding: "2rem" }}>
      <h1>MachineLearningChallenge Registration Page</h1>
      <p>This is a placeholder for the registration form for MachineLearningChallenge.</p>
    </div>
  );
};

export default MachineLearningChallenge;
