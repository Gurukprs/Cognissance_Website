import React from "react";

const AppDevelopmentChallenge = () => {
  return (
    <div style={ {padding: "2rem"} }>
      <h1>AppDevelopmentChallenge Registration Page</h1>
      <p>This is a placeholder for the registration form for AppDevelopmentChallenge.</p>
    </div>
  );
};

export default AppDevelopmentChallenge;
